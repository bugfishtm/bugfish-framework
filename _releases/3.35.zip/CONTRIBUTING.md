# Contributing

Follow these guidelines if you'd like to contribute to the project!


## Questions

If you have any questions about using or developing for this project, reach out to @bugfishtm.

## Issues

Submit an issue or pull request with a fix if you find any bugs in
the project. When submitting an issue or pull request, make sure you're as detailed as possible.

## Features

Submit an issue to request a new feature. 

🐟 Bugfish <3