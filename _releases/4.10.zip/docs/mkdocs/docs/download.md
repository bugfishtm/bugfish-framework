# Download

Here, you can easily access the latest version of the software, including all relevant files and resources.

-----------------

You can explore the complete codebase, documentation, and all the associated files in the GitHub repository. By clicking the link below, you'll be directed to the repository where you can review the project's source code, contribute to its development, report issues, and more.

[GitHub](https://github.com/bugfishtm/bugfish-framework){.md-button}

-----------------

To download the latest version of the project, simply click the link below. This will allow you to get the most up-to-date version of the repository, including all files and resources in a zip format.

[Download](https://github.com/bugfishtm/bugfish-framework/archive/refs/heads/main.zip){.md-button}
