# 📖 Documentation

This folder contains project documentation that can be accessed through any web browser. The `index.html` file holds the main local web documentation, providing essential information to understand and use the project effectively. 

Folders labeled `extra_*` contain third-party documentation, which can typically be accessed from within the main `index.html` documentation.

🐟 Bugfish